﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
[AddComponentMenu("Control Script/FPS Input")]

public class FPSInput : MonoBehaviour
{
    public float walkSpeed = 6.0f;
    public float gravity = -9.8f;

    public float jumpSpeed = 15.0f;
    public float terminalVelocity = -10.0f;
    public float minFall = -1.5f;

    private CharacterController charController;
    private float vertSpeed;

    void Start()
    {
        charController = GetComponent<CharacterController>();
        vertSpeed = minFall;
    }

    void Update()
    {

        // player movement with WASD input
        float deltaX = Input.GetAxis("Horizontal") * walkSpeed;
        float deltaZ = Input.GetAxis("Vertical") * walkSpeed;
        Vector3 movement = new Vector3(deltaX, 0, deltaZ);
        movement = Vector3.ClampMagnitude(movement, walkSpeed);
        movement.y = gravity;

        // jump action with space input
        if(charController.isGrounded)
        {
            if (Input.GetButtonDown("Jump"))
            {
                vertSpeed = jumpSpeed;
            }
            else
            {
                vertSpeed = minFall;
            }
        }
        else
        {
            vertSpeed += gravity * 5 * Time.deltaTime;
            if (vertSpeed < terminalVelocity)
            {
                vertSpeed = terminalVelocity;
            }
        }
        movement.y = vertSpeed;

        movement *= Time.deltaTime;
        movement = transform.TransformDirection(movement);
        charController.Move(movement);
    }
}
