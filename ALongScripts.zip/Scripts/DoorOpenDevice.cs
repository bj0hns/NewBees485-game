﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorOpenDevice : MonoBehaviour
{
    [SerializeField] public Vector3 doorPos;

    private bool openDoor;

    public void Operate()
    {
        if(openDoor)
        {
            Vector3 pos = transform.position - doorPos;
            transform.position = pos;
        }
        else
        {
            Vector3 pos = transform.position + doorPos;
            transform.position = pos;
        }

        openDoor = !openDoor;
    }
}
